﻿using Dapper;
using Microsoft.Data.Sqlite;
using System.Data;

namespace CadastroClientes.Common.Data;

public class DataContext(IConfiguration Configuration)
{
    public IDbConnection CreateConnection()
        => new SqliteConnection(Configuration.GetConnectionString("ClientesDatabase"));

    public async Task Init()
    {
        using var connection = CreateConnection();
        await Init();

        async Task Init()
        {
            var sql = """
                CREATE TABLE IF NOT EXISTS 
                Clientes (
                    Id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    Nome TEXT,
                    Email TEXT,
                    Saldo REAL
                );
            """;
            await connection.ExecuteAsync(sql);
        }
    }

    //public async Task<dynamic> GetById(int id)
    //{
    //    using var connection = CreateConnection();
    //    var sql = """
    //        SELECT * FROM Users 
    //        WHERE Id = @id
    //    """;
    //    return await connection.QuerySingleOrDefaultAsync<dynamic>(sql, new { id });
    //}
}
