﻿using CadastroClientes.Common.Contracts;
using CadastroClientes.Common.Results;
using Microsoft.Extensions.DependencyInjection.Extensions;
using System.Reflection;

namespace CadastroClientes.Common.Extensions;

public static class Extensions
{
    public static IServiceCollection AddEndpoints(this IServiceCollection services, Assembly assembly)
    {
        ServiceDescriptor[] serviceDescriptors = assembly
            .DefinedTypes
            .Where(type => type is { IsAbstract: false, IsInterface: false } &&
                           type.IsAssignableTo(typeof(IEndpoint)))
            .Select(type => ServiceDescriptor.Transient(typeof(IEndpoint), type))
            .ToArray();

        services.TryAddEnumerable(serviceDescriptors);

        return services;
    }

    public static IApplicationBuilder MapEndpoints(
    this WebApplication app,
    RouteGroupBuilder? routeGroupBuilder = null)
    {
        IEnumerable<IEndpoint> endpoints = app.Services
            .GetRequiredService<IEnumerable<IEndpoint>>();

        IEndpointRouteBuilder builder =
            routeGroupBuilder is null ? app : routeGroupBuilder;

        foreach (IEndpoint endpoint in endpoints)
            endpoint.MapEndpoint(builder);

        return app;
    }
    public static IResult ToApiResult(this Result result)
    {
        if (result.IsSuccess)
            return Microsoft.AspNetCore.Http.Results.Ok(result.Data);

        return result.Message switch
        {
            "Usuário não encontrado" => Microsoft.AspNetCore.Http.Results.NotFound(result.Message),
            "Erro de validação" or "Usuário já cadastrado" or "Saldo insuficiente para realizar o saque" => Microsoft.AspNetCore.Http.Results.BadRequest(result.Message),
            "" => Microsoft.AspNetCore.Http.Results.Json(result.Message, statusCode: 401),
            _ => Microsoft.AspNetCore.Http.Results.BadRequest(result.Message)
        };
    }

}
