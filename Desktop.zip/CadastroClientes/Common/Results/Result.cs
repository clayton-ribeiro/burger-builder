﻿namespace CadastroClientes.Common.Results;

public class Result
{
    public bool IsSuccess { get; }
    public string Message { get; }

    public object? Data { get; }

    protected Result(bool isSuccess, string message)
    {
        IsSuccess = isSuccess;
        Message = message;
    }

    protected Result(bool isSuccess, string message, object? data)
    {
        IsSuccess = isSuccess;
        Message = message;
        Data = data;
    }

    public static Result Success() => new(true, "Operação realizada com sucesso");
    public static Result Success(object data) => new(true, "Operação realizada com sucesso", data);
    public static Result Failure(string error) => new(false, error);

}

