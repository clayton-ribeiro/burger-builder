﻿namespace CadastroClientes.Features.Clientes;

public class BuscarClientePorId(DataContext context) : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
      => app.MapGet("clientes/{id}", Handler)
            .WithTags("Clientes")
            .WithDescription("RETORNAR OS DETALHES DE UM DETERMINADO CLIENTES PELO ID");
    public async Task<IResult> Handler(int id)
    {
        var result = await BuscarClientePorIdAsync(id);
        return result.ToApiResult();
    }

    public async Task<Result> BuscarClientePorIdAsync(int id)
    {
        using var connection = context.CreateConnection();

        var cliente = await connection.QueryFirstOrDefaultAsync<Cliente>(Query, new { id });

        if (cliente is null)
            return Result.Failure("Usuário não encontrado");

        return Result.Success(cliente);
    }

    private const string Query = @"SELECT * FROM Clientes WHERE Id = @id;";
}
