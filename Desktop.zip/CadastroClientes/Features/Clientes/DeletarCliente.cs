﻿namespace CadastroClientes.Features.Clientes;

public class DeletarCliente(DataContext context) : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
     => app.MapDelete("clientes/{id}", Handler)
           .WithTags("Clientes")
           .WithDescription("EXCLUI O CADASTRO DE UM CLIENTE");

    public async Task<IResult> Handler(int id)
    {
        var result = await DeletarClienteAsync(id);
        return result.ToApiResult();
    }

    public async Task<Result> DeletarClienteAsync(int id)
    {
        using var connection = context.CreateConnection();

        var cliente = await connection.QueryFirstOrDefaultAsync<Cliente>(QueryBuscarPorId, new { id });

        if (cliente is null)
            return Result.Failure("Usuário não encontrado");

        await connection.ExecuteAsync(QueryDeletar, new { id });

        return Result.Success();
    }

    private const string QueryBuscarPorId = @"SELECT * FROM Clientes WHERE Id = @id;";
    private const string QueryDeletar = @"DELETE FROM Clientes WHERE Id = @id;";
}
