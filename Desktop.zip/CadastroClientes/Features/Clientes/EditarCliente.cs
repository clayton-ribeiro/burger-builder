﻿namespace CadastroClientes.Features.Clientes;

public class EditarCliente(DataContext context) : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
      => app.MapPut("clientes/{id}", Handler)
            .WithTags("Clientes")
            .WithDescription("EDITA O CADASTRO DE UM CLIENTE JÁ EXISTENTE");

    public record RequestEditarCliente(string Nome, string Email);
    public async Task<IResult> Handler(int id, [FromBody] RequestEditarCliente request)
    {
        var result = await EditarClienteAsync(id, request);
        return result.ToApiResult();
    }

    public async Task<Result> EditarClienteAsync(int id, RequestEditarCliente request)
    {
        using var connection = context.CreateConnection();

        var cliente = await connection.QueryFirstOrDefaultAsync<Cliente>(QueryBuscaPorId, new { id });

        if (cliente is null)
            return Result.Failure("Usuário não encontrado");

        await connection.ExecuteAsync(QueryAtualizar, new { id, request.Nome, request.Email });

        return Result.Success();
    }

    private const string QueryBuscaPorId = @"SELECT * FROM Clientes WHERE Id = @id;";
    private const string QueryAtualizar = @"UPDATE Clientes SET Nome = @Nome, Email = @Email WHERE Id = @id;";
}
