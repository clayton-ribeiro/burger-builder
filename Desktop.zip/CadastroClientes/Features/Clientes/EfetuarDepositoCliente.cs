﻿namespace CadastroClientes.Features.Clientes;

public class EfetuarDepositoCliente(DataContext context, TaskQueueService _taskQueue) : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
     => app.MapPost("clientes/{id}/depositar", Handler)
           .WithTags("Clientes")
           .WithDescription("ADICIONA DETERMINADO VALOR DO SALDO DE UM CLIENTE");

    public record RequestEfetuarDepositoCliente(float Saldo);
    public async Task<IResult> Handler(int id, [FromBody] RequestEfetuarDepositoCliente request)
    {
        var currentTask = new TaskCompletionSource<Result>();

        await _taskQueue.EnqueueAsync(async token =>
        {
            currentTask.SetResult(await EfetuarDepositoAsync(id, request));
        });

        Result result = await currentTask.Task;

        return result.ToApiResult();
    }

    public async Task<Result> EfetuarDepositoAsync(int id, RequestEfetuarDepositoCliente request)
    {
        using var connection = context.CreateConnection();

        var cliente = await connection.QueryFirstOrDefaultAsync<Cliente>(QueryBuscaPorId, new { id });

        if (cliente is null)
            return Result.Failure("Usuário não encontrado");

        float saldo = cliente.Saldo + request.Saldo;

        await connection.ExecuteAsync(QueryDeposito, new { id, saldo });

        return Result.Success();
    }

    private const string QueryBuscaPorId = @"SELECT * FROM Clientes WHERE Id = @id;";
    private const string QueryDeposito = @"UPDATE Clientes SET Saldo = @saldo WHERE Id = @id;";
}
