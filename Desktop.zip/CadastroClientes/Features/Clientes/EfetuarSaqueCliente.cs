﻿namespace CadastroClientes.Features.Clientes;

public class EfetuarSaqueCliente(DataContext context, TaskQueueService _taskQueue) : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
      => app.MapPost("clientes/{id}/sacar", Handler)
            .WithTags("Clientes")
            .WithDescription("SUBTRAI DETERMINADO VALOR DO SALDO DE UM CLIENTE");

    public record RequestEfetuarSaqueCliente(float Saldo);
    public async Task<IResult> Handler(int id, [FromBody] RequestEfetuarSaqueCliente request)
    {
        var currentTask = new TaskCompletionSource<Result>();

        await _taskQueue.EnqueueAsync(async token =>
        {
            currentTask.SetResult(await EfetuarSaqueAsync(id, request));
        });

        Result result = await currentTask.Task;

        return result.ToApiResult();
    }

    public async Task<Result> EfetuarSaqueAsync(int id, RequestEfetuarSaqueCliente request)
    {
        using var connection = context.CreateConnection();

        var cliente = await connection.QueryFirstOrDefaultAsync<Cliente>(QueryBuscaPorId, new { id });

        if (cliente is null)
            return Result.Failure("Usuário não encontrado");

        float saldo = cliente.Saldo - request.Saldo;

        if (saldo < 0)
            return Result.Failure("Saldo insuficiente para realizar o saque");

        await connection.ExecuteAsync(QuerySaque, new { id, saldo });

        return Result.Success();
    }

    private const string QueryBuscaPorId = @"SELECT * FROM Clientes WHERE Id = @id;";
    private const string QuerySaque = @"UPDATE Clientes SET Saldo = @saldo WHERE Id = @id;";
}
