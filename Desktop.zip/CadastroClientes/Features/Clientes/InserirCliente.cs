﻿namespace CadastroClientes.Features.Clientes;

public class InserirCliente(DataContext context) : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
      => app.MapPost("clientes", Handler)
            .WithTags("Clientes")
            .WithDescription("REALIZA O CADASTRO DE UM NOVO CLIENTE");
    public record RequestInserirCliente(string Nome, string Email, float Saldo);
    
    public async Task<IResult> Handler(RequestInserirCliente request)
    {
        var result = await InserirClienteAsync(request);
        return result.ToApiResult();
    }

    public async Task<Result> InserirClienteAsync(RequestInserirCliente request)
    {
        using var connection = context.CreateConnection();

        var cliente = await connection.QueryFirstOrDefaultAsync<Cliente>(QueryBuscaPorNome, new { request.Nome });

        if (cliente is not null)
            return Result.Failure("Usuário já cadastrado");

        await connection.ExecuteAsync(QueryInserir, request);

        return Result.Success();
    }

    private const string QueryInserir = @"INSERT INTO Clientes (Nome, Email, Saldo)
                                   VALUES (@Nome, @Email, @Saldo)";

    private const string QueryBuscaPorNome = @"SELECT * FROM Clientes WHERE Nome = @Nome;";
}
