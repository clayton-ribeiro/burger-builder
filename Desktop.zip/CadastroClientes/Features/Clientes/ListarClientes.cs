﻿namespace CadastroClientes.Features.Clientes;

public class ListarClientes(DataContext context) : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
       => app.MapGet("clientes", Handler)
             .WithTags("Clientes")
             .WithDescription("LISTAR TODOS OS CLIENTES CADASTRADOS");

    public async Task<IResult> Handler()
    {
        var result = await ListarClientesAsync();
        return result.ToApiResult();
    }

    private async Task<Result> ListarClientesAsync()
    {
        using var connection = context.CreateConnection();
        return Result.Success(await connection.QueryAsync<Response>(Query));
    }

    private class Response
    {
        [JsonProperty("id")]
        public int Id { get; init; }
        [JsonProperty("nome")]
        public required string Nome { get; init; }
        [JsonProperty("email")]
        public required string Email { get; init; }
        [JsonProperty("saldo")]
        public float Saldo { get; init; }
    }

    private const string Query = "SELECT * FROM Clientes";
}
