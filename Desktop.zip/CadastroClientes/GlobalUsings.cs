﻿
global using CadastroClientes.Common.Contracts;
global using CadastroClientes.Common.Data;
global using CadastroClientes.Common.Extensions;
global using CadastroClientes.Common.Results;
global using CadastroClientes.Shared.Domain.Entities;
global using Dapper;
global using Microsoft.AspNetCore.Mvc;
global using Newtonsoft.Json;
global using Asp.Versioning;
global using Asp.Versioning.Builder;
global using Asp.Versioning.Conventions;
global using CadastroClientes.Shared.BackgroundServices;
global using CadastroClientes.Shared.Services;