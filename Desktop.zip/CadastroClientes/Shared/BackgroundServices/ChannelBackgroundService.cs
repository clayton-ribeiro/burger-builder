﻿namespace CadastroClientes.Shared.BackgroundServices;

public class ChannelBackgroundService(TaskQueueService _taskQueue, ILogger<ChannelBackgroundService> _logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Background service iniciado.");

        await foreach (var workItem in _taskQueue.DequeueAllAsync(stoppingToken))
        {
            try
            {
                await workItem(stoppingToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao processar operação.");
            }
        }

        _logger.LogInformation("Background service parado.");
    }
}
