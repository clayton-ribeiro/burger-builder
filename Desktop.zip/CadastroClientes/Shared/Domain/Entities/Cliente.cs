﻿namespace CadastroClientes.Shared.Domain.Entities;

public class Cliente
{
    public int Id { get; init; }
    public required string Nome { get; init; }
    public required string Email { get; init; }
    public float Saldo { get; init; }
}
