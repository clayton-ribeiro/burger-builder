﻿using System.Runtime.CompilerServices;
using System.Threading.Channels;

namespace CadastroClientes.Shared.Services;

public class TaskQueueService
{
    private readonly Channel<Func<CancellationToken, Task>> _queue = Channel.CreateUnbounded<Func<CancellationToken, Task>>();
    public async Task EnqueueAsync(Func<CancellationToken, Task> workItem) => await _queue.Writer.WriteAsync(workItem);

    public async IAsyncEnumerable<Func<CancellationToken, Task>> DequeueAllAsync([EnumeratorCancellation] CancellationToken cancellationToken)
    {
        while (await _queue.Reader.WaitToReadAsync(cancellationToken))
        {
            while (_queue.Reader.TryRead(out var workItem))
            {
                yield return workItem;
            }
        }
    }
}
